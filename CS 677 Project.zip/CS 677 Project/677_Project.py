# -*- coding: utf-8 -*-
"""
Created on Sun Nov 29 21:58:43 2020

@author: Alicia
"""

import numpy as np
import pandas as pd
from sklearn . naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn . ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn import tree
from sklearn.preprocessing import StandardScaler , LabelEncoder
from sklearn.metrics import confusion_matrix




print()

# Import CSV
Happiness = pd.read_csv("Happiness.csv") 

# Create Dataframes
Happiness_df  = pd.DataFrame(Happiness)

#Split into Train and test
train, test = train_test_split(Happiness_df, test_size=0.5, random_state=123)

X = np.array(train[["Region","GDP","Social_support","Life_Expectancy","Life_Choices","Generosity","Corruption"]])
X1 = np.array(train[["GDP"]])
X2 = np.array(train[["Social_support"]])
X3 = np.array(train[["Life_Expectancy"]])
X4 = np.array(train[["Life_Choices"]])
X5 = np.array(train[["Generosity"]])
X6 = np.array(train[["Corruption"]])
X7 = np.array(train[["Region"]])
Y = np.array(train[["Ladder_score"]].values.ravel())

X_test = np.array(test[["Region", "GDP","Social_support","Life_Expectancy","Life_Choices","Generosity","Corruption"]])
test_X1 = np.array(train[["GDP"]])
test_X2 = np.array(train[["Social_support"]])
test_X3 = np.array(train[["Life_Expectancy"]])
test_X4 = np.array(train[["Life_Choices"]])
test_X5 = np.array(train[["Generosity"]])
test_X6 = np.array(train[["Corruption"]])
test_X7 = np.array(train[["Region"]])
Y_test = np.array(test[["Ladder_score"]].values.ravel())

#Function for NB
def nb_cl(x, y, xt, yt):
    NB_classifier = GaussianNB().fit(x, y)
    prediction = NB_classifier.predict(x)
    error_rate = np. mean( prediction != yt)
    return(error_rate, prediction)

all_e, all_a =  nb_cl(X,Y, X_test, Y_test)
gdp_e, gdp_a = nb_cl(X1,Y, test_X1, Y_test)
ss_e, ss_a = nb_cl(X2,Y, test_X2, Y_test)
le_e, le_a = nb_cl(X3,Y, test_X3, Y_test)
lc_e, lc_a = nb_cl(X4,Y, test_X4, Y_test)
g_e, g_a = nb_cl(X5,Y, test_X5, Y_test)
c_e, c_a = nb_cl(X6,Y, test_X6, Y_test)
r_e, r_a = nb_cl(X7,Y, test_X6, Y_test)

#Compute accuracy

accuracy_1 =[]
accuracy_2 =[]
accuracy_3 =[]
accuracy_4 =[]
accuracy_5 =[]
accuracy_6 =[]
accuracy_7 =[]
accuracy_8 =[]

acc = Y_test.tolist()

def accuracy(x,y):
    i = 0
    z = 0
    for e in x:
        if x[i] == y[i]:
            z = z+1
        i=i+1
    return(z/len(x))


print("Naive Bayes Attribute Error Rate & Accuracy" )
print()
print("GDP", gdp_e, accuracy(gdp_a, acc))
print("Social Support", ss_e, accuracy(ss_a, acc))
print("Life Expectancy", le_e, accuracy(le_a, acc))
print("Life Choices", lc_e, accuracy(lc_a, acc))
print("Generosity", g_e, accuracy(g_a, acc ))
print("Corruption", c_e, accuracy(c_a, acc ))
print("Region", r_e, accuracy(r_a, acc ))
print("All Attributes", all_e, accuracy(all_a, acc ))


print("Naive Bayes confusion", confusion_matrix(lc_a, Y_test))

#Logistic

def logistic(a,b,c,d): 
    log_reg_classifier = LogisticRegression ()
    log_reg_classifier . fit ( a, b)
    prediction = log_reg_classifier . predict (c)
    accuracy = np. mean ( prediction == d)
    return(accuracy)

#returns prediction
def logistic2(a,b,c,d): 
    log_reg_classifier = LogisticRegression ()
    log_reg_classifier . fit ( a, b)
    prediction = log_reg_classifier . predict (c)
    accuracy = np. mean ( prediction == d)
    return(prediction)

z2 = np.array(train[["Region","GDP","Social_support","Life_Expectancy","Life_Choices","Generosity","Corruption"]])
z2_test = np.array(test[["Region","GDP","Social_support","Life_Expectancy","Life_Choices","Generosity","Corruption"]])
all_log = logistic(z2, Y, z2_test, Y_test)


gdp_log = logistic(X1, Y, test_X1, Y_test)
ss_log = logistic(X2, Y, test_X2, Y_test)
le_log = logistic(X3, Y, test_X3, Y_test)
lc_log = logistic(X4, Y, test_X4, Y_test)
g_log = logistic(X5, Y, test_X5, Y_test)
c_log = logistic(X6, Y, test_X6, Y_test)
r_log = logistic(X7, Y, test_X7, Y_test)





print()
print("Logistic Regression Accuracy")
print()
print("Logistic All:", all_log)
print("GDP:", gdp_log )
print("Social Support:", ss_log )
print("Life Expectancy:", le_log)
print("Life Choices:", lc_log)
print("Generosity:", g_log)
print("Corruption:", c_log)
print("Region:", r_log)
print("Logistic confusion", confusion_matrix(logistic2(z2, Y, z2_test, Y_test), Y_test))


#Run Random Forest Classifier
def r_forest (X,Y, X_test, Y_test, n, d):
    model = RandomForestClassifier ( n_estimators = n , max_depth = d ,
    criterion ='entropy')
    model . fit ( X , Y)
    prediction = model . predict ( X_test )
    error_rate = np. mean ( prediction != Y_test )
    return(error_rate)

#Returns prediction
def r_forest2 (X,Y, X_test, Y_test, n, d):
    model = RandomForestClassifier ( n_estimators = n , max_depth = d ,
    criterion ='entropy')
    model . fit ( X , Y)
    prediction = model . predict ( X_test )
    error_rate = np. mean ( prediction != Y_test )
    return(prediction)



print()
print("Random Forrest")
print("N = 1, D = 1, Error Rate ", r_forest(z2,Y, z2_test, Y_test, 1,1))
print("N = 1, D = 2, Error Rate ", r_forest(z2,Y, z2_test, Y_test, 1,2))
print("N = 1, D = 3 , Error Rate ", r_forest(z2,Y, z2_test, Y_test, 1,3))
print("N = 1, D = 4, Error Rate ", r_forest(z2,Y, z2_test, Y_test, 1,4))
print("N = 1, D = 5, Error Rate ", r_forest(z2,Y, z2_test, Y_test, 1,5))
      
print("N = 2, D = 1, Error Rate ", r_forest(z2,Y, z2_test,Y_test, 2,1))
print("N = 2, D = 2, Error Rate ", r_forest(z2,Y, z2_test,Y_test, 2,2))
print("N = 2, D = 3, Error Rate ", r_forest(z2,Y, z2_test, Y_test,2,3))
print("N = 2, D = 4, Error Rate ", r_forest(z2,Y, z2_test, Y_test,2,4))
print("N = 2, D = 5, Error Rate ", r_forest(z2,Y, z2_test, Y_test,2,5))
                  
print("N = 3, D = 1, Error Rate ", r_forest(z2,Y, z2_test,Y_test, 3,1))
print("N = 3, D = 2, Error Rate ", r_forest(z2,Y, z2_test, Y_test,3,2))
print("N = 3, D = 3, Error Rate ", r_forest(z2,Y, z2_test, Y_test,3,3))
print("N = 3, D = 4, Error Rate ", r_forest(z2,Y, z2_test,Y_test, 3,4))
print("N = 3, D = 5, Error Rate ", r_forest(z2,Y, z2_test, Y_test,3,5))
     
print("N = 4, D = 1, Error Rate ", r_forest(z2,Y, z2_test,Y_test, 4,1))
print("N = 4, D = 2, Error Rate ", r_forest(z2,Y, z2_test,Y_test, 4,2))
print("N = 4, D = 3, Error Rate ", r_forest(z2,Y, z2_test, Y_test,4,3))
print("N = 4, D = 4, Error Rate ", r_forest(z2,Y, z2_test, Y_test,4,4))
print("N = 4, D = 5, Error Rate ", r_forest(z2,Y, z2_test, Y_test,4,5))  

print("N = 5, D = 1, Error Rate ", r_forest(z2,Y, z2_test, Y_test,5,1))
print("N = 5, D = 2, Error Rate ", r_forest(z2,Y, z2_test,Y_test, 5,2))
print("N = 5, D = 3, Error Rate ", r_forest(z2,Y, z2_test,Y_test, 5,3))
print("N = 5, D = 4, Error Rate ", r_forest(z2,Y, z2_test, Y_test,5,4))
print("N = 5, D = 5, Error Rate ", r_forest(z2,Y, z2_test, Y_test,5,5))


print("Random Forest confusion 5,5", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,5,5), Y_test))
print("Random Forest confusion 5,4", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,5,4), Y_test))
print("Random Forest confusion 5,3", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,5,3), Y_test))
print("Random Forest confusion 5,2", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,5,2), Y_test))
print("Random Forest confusion 5,1", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,5,1), Y_test))

print("Random Forest confusion 4,5", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,4,5), Y_test))
print("Random Forest confusion 4,4", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,4,4), Y_test))
print("Random Forest confusion 4,3", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,4,3), Y_test))
print("Random Forest confusion 4,2", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,4,2), Y_test))
print("Random Forest confusion 4,1", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,4,1), Y_test))


print("Random Forest confusion 3,5", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,3,5), Y_test))
print("Random Forest confusion 3,4", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,3,4), Y_test))
print("Random Forest confusion 3,3", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,3,3), Y_test))
print("Random Forest confusion 3,2", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,3,2), Y_test))
print("Random Forest confusion 3,1", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,3,1), Y_test))

print("Random Forest confusion 2,5", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,2,5), Y_test))
print("Random Forest confusion 2,4", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,2,4), Y_test))
print("Random Forest confusion 2,3", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,2,3), Y_test))
print("Random Forest confusion 2,2", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,2,2), Y_test))
print("Random Forest confusion 2,1", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,2,1), Y_test))

print("Random Forest confusion 1,5", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,1,5), Y_test))
print("Random Forest confusion 1,4", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,1,4), Y_test))
print("Random Forest confusion 1,3", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,1,3), Y_test))
print("Random Forest confusion 1,2", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,1,2), Y_test))
print("Random Forest confusion 1,1", confusion_matrix(r_forest2(z2,Y, z2_test, Y_test,1,1), Y_test))







#KNN  3 - 7

#Run the classifier for all

scaler = StandardScaler().fit(z2)
train_k3= scaler.transform(z2)

y_test_list = list(Y_test)

knn_classifier = KNeighborsClassifier(n_neighbors =2)
knn_classifier.fit(z2,np.ravel(Y))
pred_k2 = knn_classifier.predict (z2_test)
conf_k2 = confusion_matrix(y_test_list, pred_k2, ["Happy", "Unhappy"])
k2_accuracy = knn_classifier.score (z2, np.ravel(Y))



knn_classifier = KNeighborsClassifier(n_neighbors =3)
knn_classifier.fit(z2,np.ravel(Y))
pred_k3 = knn_classifier.predict (z2_test)
conf_k3 = confusion_matrix(y_test_list, pred_k3, ["Happy", "Unhappy"])
k3_accuracy = knn_classifier.score (z2, np.ravel(Y))


print()
print("K Nearest Neighbors")


knn_classifier = KNeighborsClassifier(n_neighbors =4)
knn_classifier.fit(z2,np.ravel(Y))
pred_k4 = knn_classifier.predict (z2_test)
conf_k4 = confusion_matrix(y_test_list, pred_k4, ["Happy", "Unhappy"])
k4_accuracy = knn_classifier.score (z2, np.ravel(Y))



knn_classifier = KNeighborsClassifier(n_neighbors =5)
knn_classifier.fit(z2,np.ravel(Y))
pred_k5 = knn_classifier.predict (z2_test)
conf_k5 = confusion_matrix(y_test_list, pred_k5, ["Happy", "Unhappy"])
k5_accuracy = knn_classifier.score (z2, np.ravel(Y))



knn_classifier = KNeighborsClassifier(n_neighbors =6)
knn_classifier.fit(z2,np.ravel(Y))
pred_k6 = knn_classifier.predict (z2_test)
conf_k6 = confusion_matrix(y_test_list, pred_k6, ["Happy", "Unhappy"])
k6_accuracy = knn_classifier.score (z2, np.ravel(Y))



knn_classifier = KNeighborsClassifier(n_neighbors =7)
knn_classifier.fit(z2,np.ravel(Y))
pred_k7 = knn_classifier.predict (z2_test)
conf_k7 = confusion_matrix(y_test_list, pred_k7, ["Happy", "Unhappy"])
k7_accuracy = knn_classifier.score (z2, np.ravel(Y))




knn_classifier = KNeighborsClassifier(n_neighbors =8)
knn_classifier.fit(z2,np.ravel(Y))
pred_k8 = knn_classifier.predict (z2_test)
conf_k8 = confusion_matrix(y_test_list, pred_k8, ["Happy", "Unhappy"])
k8_accuracy = knn_classifier.score (z2, np.ravel(Y))



print("KNN 3 confusion", confusion_matrix(pred_k3, Y_test))
print("KNN 4 confusion", confusion_matrix(pred_k4, Y_test))
print("KNN 5 confusion", confusion_matrix(pred_k5, Y_test))
print("KNN 6 confusion", confusion_matrix(pred_k6, Y_test))
print("KNN 4 confusion", confusion_matrix(pred_k7, Y_test))




#Run Decision Tree Classifier

tree_classifier = tree.DecisionTreeClassifier (criterion = "entropy")
tree_classifier = tree_classifier . fit(X,Y)
dt_prediction = tree_classifier . predict ( X_test )
dt_error_rate = np. mean ( dt_prediction != Y_test )



print()
print("Decision Tree accuracy", 1 - dt_error_rate)
print("Decision Tree confusion", confusion_matrix(dt_prediction, Y_test))

